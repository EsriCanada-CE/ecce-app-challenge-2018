define({
  "_widgetLabel": "ヘッダー",
  "signin": "サイン イン",
  "signout": "サイン アウト",
  "about": "情報",
  "signInTo": "サイン イン",
  "cantSignOutTip": "この関数は、プレビュー モードでは使用できません。"
});