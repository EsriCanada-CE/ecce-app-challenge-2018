define({
  "_widgetLabel": "錨定列控制器",
  "_layout_default": "預設版面配置",
  "_layout_layout1": "版面配置 0",
  "more": "更多 widget"
});