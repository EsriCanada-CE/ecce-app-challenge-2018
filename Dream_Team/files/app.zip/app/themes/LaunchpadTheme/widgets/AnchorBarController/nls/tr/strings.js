define({
  "_widgetLabel": "Tutturucu Çubuğu Denetleyicisi",
  "_layout_default": "Varsayılan düzen",
  "_layout_layout1": "Düzen 0",
  "more": "Daha fazla araç"
});