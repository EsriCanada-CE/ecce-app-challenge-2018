define({
  "_widgetLabel": "Kontroler trake polazne tačke",
  "_layout_default": "Podrazumevani raspored",
  "_layout_layout1": "Raspored 0",
  "more": "Više vidžeta"
});