define({
  "_widgetLabel": "标头控制器",
  "_layout_default": "默认布局",
  "_layout_layout1": "布局 0",
  "more": "更多微件"
});