define({
  "_themeLabel": "Тема Launchpad",
  "_layout_default": "Компоновка по умолчанию",
  "_layout_right": "Компоновка по правому краю"
});