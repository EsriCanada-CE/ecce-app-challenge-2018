define({
  "_themeLabel": "लॉन्चपैड थीम",
  "_layout_default": "डिफ़ॉल्ट रूपरेखा",
  "_layout_right": "सही लेआउट"
});