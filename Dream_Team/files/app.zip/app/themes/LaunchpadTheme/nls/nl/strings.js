define({
  "_themeLabel": "Launchpad Thema",
  "_layout_default": "Standaardlay-out",
  "_layout_right": "Juiste lay-out"
});