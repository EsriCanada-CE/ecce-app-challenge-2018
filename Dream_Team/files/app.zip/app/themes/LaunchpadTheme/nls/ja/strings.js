define({
  "_themeLabel": "ローンチパッド テーマ",
  "_layout_default": "デフォルトのレイアウト",
  "_layout_right": "右側のレイアウト"
});