define({
  "_themeLabel": "Motyw Launchpad",
  "_layout_default": "Kompozycja domyślna",
  "_layout_right": "Kompozycja prawostronna"
});